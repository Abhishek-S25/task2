-- ============================================================
-- Inventory, Order & Payment Management System
-- Database: inventory_management
-- Engine: InnoDB, Charset: utf8mb4
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";

CREATE DATABASE IF NOT EXISTS `inventory_management`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `inventory_management`;

-- ------------------------------------------------------------
-- roles
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL,
  `status` TINYINT NOT NULL DEFAULT 1 COMMENT '1=active,0=inactive',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_roles_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- users
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_id` INT UNSIGNED NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(150) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `status` TINYINT NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email` (`email`),
  KEY `fk_users_role` (`role_id`),
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- categories
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `description` VARCHAR(255) NULL,
  `status` TINYINT NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_categories_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- products
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `category_id` INT UNSIGNED NOT NULL,
  `sku` VARCHAR(50) NOT NULL,
  `name` VARCHAR(150) NOT NULL,
  `description` TEXT NULL,
  `image` VARCHAR(255) NULL,
  `price` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `stock` INT NOT NULL DEFAULT 0,
  `status` TINYINT NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_products_sku` (`sku`),
  KEY `fk_products_category` (`category_id`),
  KEY `idx_products_name` (`name`),
  CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- customers
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(150) NOT NULL,
  `mobile` VARCHAR(20) NOT NULL,
  `email` VARCHAR(150) NULL,
  `address` VARCHAR(255) NULL,
  `gst_no` VARCHAR(20) NULL,
  `status` TINYINT NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_customers_mobile` (`mobile`),
  KEY `idx_customers_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- orders
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_no` VARCHAR(30) NOT NULL,
  `customer_id` INT UNSIGNED NOT NULL,
  `subtotal` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `tax` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `discount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `grand_total` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `paid_amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `payment_status` ENUM('Pending','Partial','Paid','Failed','Refunded') NOT NULL DEFAULT 'Pending',
  `order_status` ENUM('New','Processing','Completed','Cancelled') NOT NULL DEFAULT 'New',
  `created_by` INT UNSIGNED NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_orders_order_no` (`order_no`),
  KEY `fk_orders_customer` (`customer_id`),
  KEY `fk_orders_created_by` (`created_by`),
  KEY `idx_orders_status` (`order_status`, `payment_status`),
  CONSTRAINT `fk_orders_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT `fk_orders_created_by` FOREIGN KEY (`created_by`) REFERENCES `users`(`id`)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- order_items
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id` INT UNSIGNED NOT NULL,
  `product_id` INT UNSIGNED NOT NULL,
  `qty` INT NOT NULL,
  `price` DECIMAL(12,2) NOT NULL,
  `amount` DECIMAL(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_items_order` (`order_id`),
  KEY `fk_items_product` (`product_id`),
  CONSTRAINT `fk_items_order` FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `fk_items_product` FOREIGN KEY (`product_id`) REFERENCES `products`(`id`)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- transactions
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `txn_no` VARCHAR(40) NOT NULL,
  `order_id` INT UNSIGNED NOT NULL,
  `customer_id` INT UNSIGNED NOT NULL,
  `amount` DECIMAL(12,2) NOT NULL,
  `payment_method` ENUM('Cash','Card','UPI','NetBanking','Wallet','Other') NOT NULL DEFAULT 'Cash',
  `payment_status` ENUM('Pending','Success','Failed','Refunded') NOT NULL DEFAULT 'Pending',
  `reference_no` VARCHAR(100) NULL,
  `remarks` VARCHAR(255) NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_transactions_txn_no` (`txn_no`),
  KEY `fk_txn_order` (`order_id`),
  KEY `fk_txn_customer` (`customer_id`),
  CONSTRAINT `fk_txn_order` FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT `fk_txn_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- stock_ledger
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `stock_ledger`;
CREATE TABLE `stock_ledger` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_id` INT UNSIGNED NOT NULL,
  `reference_type` ENUM('ORDER','PURCHASE','ADJUSTMENT','RETURN','CANCELLATION') NOT NULL,
  `reference_id` INT UNSIGNED NULL,
  `stock_in` INT NOT NULL DEFAULT 0,
  `stock_out` INT NOT NULL DEFAULT 0,
  `balance_stock` INT NOT NULL,
  `remarks` VARCHAR(255) NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_ledger_product` (`product_id`),
  KEY `idx_ledger_reference` (`reference_type`, `reference_id`),
  CONSTRAINT `fk_ledger_product` FOREIGN KEY (`product_id`) REFERENCES `products`(`id`)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- audit_logs
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NULL,
  `module` VARCHAR(50) NOT NULL,
  `action` VARCHAR(50) NOT NULL,
  `ip_address` VARCHAR(45) NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_audit_user` (`user_id`),
  CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- Seed data
-- ============================================================

INSERT INTO `roles` (`id`, `name`, `status`) VALUES
(1, 'Admin', 1),
(2, 'Manager', 1),
(3, 'Staff', 1);

-- password for both users = Password@123
-- bcrypt hash (compatible with PHP password_verify / PASSWORD_BCRYPT)
INSERT INTO `users` (`id`, `role_id`, `name`, `email`, `password`, `status`) VALUES
(1, 1, 'System Admin', 'admin@example.com', '$2b$12$NXbGF83bniG.MFj8I5pC6u46FlWb44euV5hSS0P5FmNx2uqwA6HwK', 1),
(2, 2, 'Store Manager', 'manager@example.com', '$2b$12$NXbGF83bniG.MFj8I5pC6u46FlWb44euV5hSS0P5FmNx2uqwA6HwK', 1);

INSERT INTO `categories` (`id`, `name`, `description`, `status`) VALUES
(1, 'Electronics', 'Electronic gadgets and accessories', 1),
(2, 'Groceries', 'Daily grocery items', 1),
(3, 'Apparel', 'Clothing and fashion items', 1);

INSERT INTO `products` (`id`, `category_id`, `sku`, `name`, `description`, `image`, `price`, `stock`, `status`) VALUES
(1, 1, 'ELEC-001', 'Wireless Mouse', 'Ergonomic wireless mouse', NULL, 599.00, 100, 1),
(2, 1, 'ELEC-002', 'USB-C Cable 1m', 'Fast charging cable', NULL, 199.00, 200, 1),
(3, 2, 'GRO-001', 'Basmati Rice 5kg', 'Premium basmati rice', NULL, 650.00, 50, 1),
(4, 3, 'APP-001', 'Cotton T-Shirt (M)', 'Round neck cotton t-shirt', NULL, 399.00, 75, 1);

INSERT INTO `customers` (`id`, `name`, `mobile`, `email`, `address`, `gst_no`, `status`) VALUES
(1, 'Rahul Sharma', '9876543210', 'rahul@example.com', 'Jabalpur, MP', NULL, 1),
(2, 'Priya Verma', '9876543211', 'priya@example.com', 'Bhopal, MP', '23ABCDE1234F1Z5', 1);

-- Opening stock ledger entries for seeded products
INSERT INTO `stock_ledger` (`product_id`, `reference_type`, `reference_id`, `stock_in`, `stock_out`, `balance_stock`, `remarks`) VALUES
(1, 'ADJUSTMENT', NULL, 100, 0, 100, 'Opening stock'),
(2, 'ADJUSTMENT', NULL, 200, 0, 200, 'Opening stock'),
(3, 'ADJUSTMENT', NULL, 50, 0, 50, 'Opening stock'),
(4, 'ADJUSTMENT', NULL, 75, 0, 75, 'Opening stock');
