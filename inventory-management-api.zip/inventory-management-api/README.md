# Inventory, Order & Payment Management System

A REST API built with **CodeIgniter 3**, **PHP 8+**, and **MySQL** for the
Senior PHP CodeIgniter Developer machine task.

---

## 1. Tech Stack

| Layer          | Choice                                            |
|----------------|----------------------------------------------------|
| Framework      | CodeIgniter 3.1.x                                  |
| Language       | PHP 8.0+                                           |
| Database       | MySQL 5.7+ / 8.0 (InnoDB, utf8mb4)                 |
| Auth           | Stateless JWT (HS256), custom dependency-free lib  |
| API style      | REST, JSON request/response, correct HTTP codes    |

---

## 2. Project Structure

```
inventory-management-api/
├── application/
│   ├── config/            # config.php, database.php, routes.php, autoload.php
│   ├── core/               MY_Controller.php (Auth_Controller - JWT + RBAC)
│   ├── controllers/api/    # Auth, Roles, Categories, Products, Customers,
│   │                       # Orders, Transactions, Stock_ledger, Reports, Dashboard
│   ├── models/              One model per table with list/CRUD helpers
│   ├── libraries/          REST_Controller, Jwt, Auditor
│   └── helpers/             response_helper.php (success/error envelopes)
├── database/
│   └── inventory_management.sql   # full schema + seed data
├── postman/
│   └── Inventory_Management_API.postman_collection.json
├── uploads/products/       # uploaded product images land here
├── index.php               # CI3 front controller (CORS-aware)
└── .htaccess
```

> **Note on `system/`:** This submission ships only the customised
> `application/` layer (the actual deliverable). To run it, download the
> official **CodeIgniter 3.1.13** framework zip from
> `https://codeigniter.com/download` (or `github.com/bcit-ci/CodeIgniter`,
> tag `3.1.13`) and copy its `system/` folder into the project root, next
> to `index.php`. This keeps the submission focused on original code only.

---

## 3. Setup

1. **Get CodeIgniter 3 core**
   Download CI 3.1.13, copy `system/` into this project root.

2. **Create the database**
   ```bash
   mysql -u root -p -e "CREATE DATABASE inventory_management CHARACTER SET utf8mb4"
   mysql -u root -p inventory_management < database/inventory_management.sql
   ```
   The SQL dump already creates the database, all tables, foreign keys,
   indexes, and seed data (roles, sample users, categories, products,
   customers, opening stock ledger).

3. **Configure DB credentials**
   Edit `application/config/database.php` (`hostname`, `username`,
   `password`).

4. **Set the JWT secret & base URL**
   Edit `application/config/config.php` → `jwt_secret`, `base_url`.

5. **Permissions**
   ```bash
   chmod -R 755 uploads/
   ```

6. **Point your web server** (Apache/Nginx) document root to the project
   folder, or run PHP's built-in server for quick testing:
   ```bash
   php -S localhost:8000
   ```

7. **Import the Postman collection** from `postman/` and set the
   `base_url` collection variable (e.g. `http://localhost:8000`).

---

## 4. Sample Credentials

Seeded in `database/inventory_management.sql` (password is bcrypt-hashed):

| Email                  | Password       | Role    |
|-------------------------|----------------|---------|
| admin@example.com       | Password@123   | Admin   |
| manager@example.com     | Password@123   | Manager |

Call `POST /api/auth/login` with these to obtain a JWT, then send it as
`Authorization: Bearer <token>` on every other request.

---

## 5. Authentication & Authorization

- Stateless **JWT (HS256)**, implemented in `application/libraries/Jwt.php`
  with zero external dependencies (pure `hash_hmac`), so no Composer
  install is required.
- Every protected controller extends `Auth_Controller`
  (`application/core/MY_Controller.php`), which verifies the bearer token
  on construction and exposes `$this->auth_user_id`, `$this->auth_role_name`.
- Simple **RBAC** via `$this->require_roles(['Admin', 'Manager'])` guards
  inside each write action (e.g. only Admin can manage Roles; Admin/Manager
  can manage Products, Categories, cancel Orders; all authenticated roles
  can create Customers/Orders/Transactions).
- Every mutating request additionally writes a row to `audit_logs`
  (`application/libraries/Auditor.php`) capturing user, module, action, IP.

---

## 6. Core Business Logic

### Order creation (`POST /api/orders`)
1. Validates the customer and every line item structurally first.
2. Opens a single DB transaction (`$this->db->trans_begin()`).
3. For each product, runs `SELECT ... FOR UPDATE` to **row-lock** it,
   preventing race conditions from concurrent orders.
4. Checks the product is active and has sufficient stock — insufficient
   stock aborts the whole order with `400 Bad Request` and a clear message,
   before anything is written.
5. Prices are taken from the **server-side** product record, never trusted
   from the client payload.
6. Inserts the `orders` row, then each `order_items` row.
7. **Only after** the order is persisted does it deduct `products.stock`
   and write a `stock_ledger` row (`reference_type = ORDER`) recording the
   exact stock-out and resulting balance.
8. Commits; any exception rolls back the entire transaction.

### Order cancellation (`PUT /api/orders/{id}/cancel`)
Restores stock for every item inside a transaction and writes a
`CANCELLATION` stock-ledger entry, then marks the order `Cancelled`.
Completed orders cannot be cancelled.

### Payments & automatic payment status (`POST /api/transactions`)
Recording a transaction against an order automatically recalculates
`orders.payment_status` from the sum of its `Success` transactions vs.
`grand_total`:

| Condition                                   | payment_status |
|----------------------------------------------|----------------|
| No successful payment, no failed attempt      | Pending        |
| No successful payment, last attempt failed    | Failed         |
| `0 < paid < grand_total`                      | Partial        |
| `paid >= grand_total`                         | Paid           |
| Refund transactions cover the paid amount     | Refunded       |

### Manual stock adjustments (`POST /api/stock-ledger/adjust`)
Lets Admin/Manager correct stock (damages, stock-take, new purchases
entered outside the order flow) with the same row-locking + ledger-entry
guarantees as order processing. Product `stock` is **not** directly
editable via `PUT /api/products/{id}` — it can only change through orders
or this endpoint, so every movement is traceable in `stock_ledger`.

---

## 7. API Overview

All endpoints are prefixed `/api` and return:
```json
{ "status": true, "message": "...", "data": { }, "meta": { } }
```
or on error:
```json
{ "status": false, "message": "...", "errors": { } }
```
with the appropriate HTTP status code (200, 201, 400, 401, 403, 404, 422, 500).

| Module        | Endpoints |
|---------------|-----------|
| Auth          | `POST /auth/login`, `POST /auth/logout`, `GET /auth/me` |
| Dashboard     | `GET /dashboard` |
| Roles         | `GET/POST /roles`, `GET/PUT/DELETE /roles/{id}` |
| Categories    | `GET/POST /categories`, `GET/PUT/DELETE /categories/{id}` |
| Products      | `GET/POST /products`, `GET/PUT/DELETE /products/{id}` (multipart image upload) |
| Customers     | `GET/POST /customers`, `GET/PUT/DELETE /customers/{id}` |
| Orders        | `GET/POST /orders`, `GET /orders/{id}`, `PUT /orders/{id}/status`, `PUT /orders/{id}/cancel` |
| Transactions  | `GET/POST /transactions`, `GET /transactions/{id}` |
| Stock Ledger  | `GET /stock-ledger`, `GET /stock-ledger/product/{id}`, `POST /stock-ledger/adjust` |
| Reports       | `GET /reports/sales`, `/reports/stock`, `/reports/low-stock`, `/reports/payments` |

List endpoints support `page`, `limit`, `search`, `sort`, `order` (asc/desc)
query params; Orders/Products/Transactions add extra filters (status,
category, date range, etc. — see the Postman collection for exact params).

---

## 8. Validation & Security

- All input validated server-side via CI's `form_validation` library
  (bound to the parsed JSON/multipart body through `set_data()`).
- Passwords hashed with `password_hash()` / verified with `password_verify()`.
- SQL executed exclusively through CodeIgniter's Query Builder / bound
  parameters — no raw string concatenation, preventing SQL injection.
- Product image uploads restricted to `jpg|jpeg|png|webp`, max 2MB, saved
  with an **encrypted/randomised filename** to prevent overwrite/traversal
  attacks; served back via `image_url` in API responses.
- `CSRF` protection is intentionally disabled at the framework level since
  this is a stateless, token-authenticated JSON API (not a session-based
  HTML form flow) — the JWT itself is the anti-forgery control.
- Row-level locking (`SELECT ... FOR UPDATE`) inside DB transactions
  prevents overselling stock under concurrent load.

---

## 9. Performance Notes

- Indexes added on all foreign keys plus frequently filtered/sorted
  columns (`products.name`, `orders.order_status`+`payment_status`,
  `customers.name`, etc.) — see `database/inventory_management.sql`.
- List endpoints always paginate (`LIMIT`/`OFFSET`) and return `meta`
  (`page`, `limit`, `total`, `total_pages`) instead of returning full
  tables.
- Reports use aggregate SQL (`SUM`, `COUNT`, `GROUP BY`) computed in the
  database rather than in PHP.

---

## 10. Submission Checklist

- [x] Source code (`application/`, `index.php`, `.htaccess`)
- [x] SQL dump (`database/inventory_management.sql`)
- [x] README (this file)
- [x] Postman collection (`postman/Inventory_Management_API.postman_collection.json`)
- [x] Sample credentials (Section 4 above)
