<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$autoload['packages'] = array();
$autoload['libraries'] = array('database', 'form_validation', 'Jwt');
$autoload['drivers'] = array();
$autoload['helper'] = array('url', 'response', 'security');
$autoload['config'] = array();
$autoload['language'] = array();
$autoload['model'] = array();
