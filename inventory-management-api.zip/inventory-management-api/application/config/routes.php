<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'api/dashboard';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

/*
|--------------------------------------------------------------------------
| Auth
|--------------------------------------------------------------------------
*/
$route['api/auth/login']['post']   = 'api/auth/login';
$route['api/auth/logout']['post']  = 'api/auth/logout';
$route['api/auth/me']['get']       = 'api/auth/me';

/*
|--------------------------------------------------------------------------
| Dashboard
|--------------------------------------------------------------------------
*/
$route['api/dashboard']['get'] = 'api/dashboard/index';

/*
|--------------------------------------------------------------------------
| Roles
|--------------------------------------------------------------------------
*/
$route['api/roles']['get']            = 'api/roles/index';
$route['api/roles']['post']           = 'api/roles/create';
$route['api/roles/(:num)']['get']     = 'api/roles/view/$1';
$route['api/roles/(:num)']['put']     = 'api/roles/update/$1';
$route['api/roles/(:num)']['delete']  = 'api/roles/delete/$1';

/*
|--------------------------------------------------------------------------
| Categories
|--------------------------------------------------------------------------
*/
$route['api/categories']['get']           = 'api/categories/index';
$route['api/categories']['post']          = 'api/categories/create';
$route['api/categories/(:num)']['get']    = 'api/categories/view/$1';
$route['api/categories/(:num)']['put']    = 'api/categories/update/$1';
$route['api/categories/(:num)']['delete'] = 'api/categories/delete/$1';

/*
|--------------------------------------------------------------------------
| Products
|--------------------------------------------------------------------------
*/
$route['api/products']['get']              = 'api/products/index';
$route['api/products']['post']             = 'api/products/create';
$route['api/products/(:num)']['get']       = 'api/products/view/$1';
$route['api/products/(:num)']['post']      = 'api/products/update/$1'; // multipart update (image)
$route['api/products/(:num)']['put']       = 'api/products/update/$1';
$route['api/products/(:num)']['delete']    = 'api/products/delete/$1';

/*
|--------------------------------------------------------------------------
| Customers
|--------------------------------------------------------------------------
*/
$route['api/customers']['get']            = 'api/customers/index';
$route['api/customers']['post']           = 'api/customers/create';
$route['api/customers/(:num)']['get']     = 'api/customers/view/$1';
$route['api/customers/(:num)']['put']     = 'api/customers/update/$1';
$route['api/customers/(:num)']['delete']  = 'api/customers/delete/$1';

/*
|--------------------------------------------------------------------------
| Orders
|--------------------------------------------------------------------------
*/
$route['api/orders']['get']                    = 'api/orders/index';
$route['api/orders']['post']                   = 'api/orders/create';
$route['api/orders/(:num)']['get']             = 'api/orders/view/$1';
$route['api/orders/(:num)/status']['put']      = 'api/orders/update_status/$1';
$route['api/orders/(:num)/cancel']['put']      = 'api/orders/cancel/$1';

/*
|--------------------------------------------------------------------------
| Transactions
|--------------------------------------------------------------------------
*/
$route['api/transactions']['get']          = 'api/transactions/index';
$route['api/transactions']['post']         = 'api/transactions/create';
$route['api/transactions/(:num)']['get']   = 'api/transactions/view/$1';

/*
|--------------------------------------------------------------------------
| Stock Ledger
|--------------------------------------------------------------------------
*/
$route['api/stock-ledger']['get']                     = 'api/stock_ledger/index';
$route['api/stock-ledger/product/(:num)']['get']      = 'api/stock_ledger/by_product/$1';
$route['api/stock-ledger/adjust']['post']             = 'api/stock_ledger/adjust';

/*
|--------------------------------------------------------------------------
| Reports
|--------------------------------------------------------------------------
*/
$route['api/reports/sales']['get']      = 'api/reports/sales';
$route['api/reports/stock']['get']      = 'api/reports/stock';
$route['api/reports/low-stock']['get']  = 'api/reports/low_stock';
$route['api/reports/payments']['get']   = 'api/reports/payments';
