<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Roles API — Admin only.
 * GET    /api/roles
 * POST   /api/roles
 * GET    /api/roles/{id}
 * PUT    /api/roles/{id}
 * DELETE /api/roles/{id}
 */
class Roles extends Auth_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Role_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $params = $this->get_list_params(array('id', 'name', 'status'), 'id');
        $result = $this->Role_model->get_list($params);
        $this->respond_success($result['rows'], 'Roles fetched.', self::HTTP_OK, $this->build_meta($result['total'], $params));
    }

    public function view($id)
    {
        $role = $this->Role_model->find($id);
        if (!$role) {
            return $this->respond_error('Role not found.', self::HTTP_NOT_FOUND);
        }
        $this->respond_success($role);
    }

    public function create()
    {
        $this->require_roles(array('Admin'));

        $this->form_validation->set_data($this->payload);
        $this->form_validation->set_rules('name', 'Name', 'required|min_length[2]|max_length[50]');
        $this->form_validation->set_rules('status', 'Status', 'permit_empty|in_list[0,1]');

        if ($this->form_validation->run() === FALSE) {
            return $this->respond_error('Validation failed.', self::HTTP_UNPROCESSABLE_ENTITY, $this->form_validation->error_array());
        }

        $name = trim($this->input('name'));
        if ($this->Role_model->name_exists($name)) {
            return $this->respond_error('A role with this name already exists.', self::HTTP_UNPROCESSABLE_ENTITY);
        }

        $id = $this->Role_model->create(array(
            'name'   => $name,
            'status' => $this->input('status', 1),
        ));

        $this->audit('roles', 'create:' . $id);
        $this->respond_success($this->Role_model->find($id), 'Role created.', self::HTTP_CREATED);
    }

    public function update($id)
    {
        $this->require_roles(array('Admin'));

        $role = $this->Role_model->find($id);
        if (!$role) {
            return $this->respond_error('Role not found.', self::HTTP_NOT_FOUND);
        }

        $this->form_validation->set_data($this->payload);
        $this->form_validation->set_rules('name', 'Name', 'permit_empty|min_length[2]|max_length[50]');
        $this->form_validation->set_rules('status', 'Status', 'permit_empty|in_list[0,1]');

        if ($this->form_validation->run() === FALSE) {
            return $this->respond_error('Validation failed.', self::HTTP_UNPROCESSABLE_ENTITY, $this->form_validation->error_array());
        }

        $data = array();
        if ($this->input('name') !== NULL) {
            $name = trim($this->input('name'));
            if ($this->Role_model->name_exists($name, $id)) {
                return $this->respond_error('A role with this name already exists.', self::HTTP_UNPROCESSABLE_ENTITY);
            }
            $data['name'] = $name;
        }
        if ($this->input('status') !== NULL) {
            $data['status'] = (int) $this->input('status');
        }

        if (!empty($data)) {
            $this->Role_model->update($id, $data);
            $this->audit('roles', 'update:' . $id);
        }

        $this->respond_success($this->Role_model->find($id), 'Role updated.');
    }

    public function delete($id)
    {
        $this->require_roles(array('Admin'));

        $role = $this->Role_model->find($id);
        if (!$role) {
            return $this->respond_error('Role not found.', self::HTTP_NOT_FOUND);
        }

        if ($this->Role_model->is_in_use($id)) {
            return $this->respond_error('Cannot delete a role that is assigned to existing users.', self::HTTP_BAD_REQUEST);
        }

        $this->Role_model->delete($id);
        $this->audit('roles', 'delete:' . $id);
        $this->respond_success(NULL, 'Role deleted.');
    }
}
