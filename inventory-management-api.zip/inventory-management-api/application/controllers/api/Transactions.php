<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Transactions API
 * GET  /api/transactions   ?search=&order_id=&customer_id=&payment_status=&page=&limit=&sort=&order=
 * POST /api/transactions    { order_id, amount, payment_method, payment_status, reference_no, remarks }
 * GET  /api/transactions/{id}
 *
 * Every successful write here triggers Order_model::recalculate_payment_status()
 * so the parent order's payment_status is always kept in sync automatically.
 */
class Transactions extends Auth_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Transaction_model');
        $this->load->model('Order_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $params = $this->get_list_params(array('id', 'txn_no', 'amount', 'created_at'), 'created_at');
        $params['order_id']       = $this->input->get('order_id');
        $params['customer_id']    = $this->input->get('customer_id');
        $params['payment_status'] = $this->input->get('payment_status');

        $result = $this->Transaction_model->get_list($params);
        $this->respond_success($result['rows'], 'Transactions fetched.', self::HTTP_OK, $this->build_meta($result['total'], $params));
    }

    public function view($id)
    {
        $txn = $this->Transaction_model->find($id);
        if (!$txn) {
            return $this->respond_error('Transaction not found.', self::HTTP_NOT_FOUND);
        }
        $this->respond_success($txn);
    }

    public function create()
    {
        $this->form_validation->set_data($this->payload);
        $this->form_validation->set_rules('order_id', 'Order', 'required|integer');
        $this->form_validation->set_rules('amount', 'Amount', 'required|decimal|greater_than[0]');
        $this->form_validation->set_rules('payment_method', 'Payment Method', 'permit_empty|in_list[Cash,Card,UPI,NetBanking,Wallet,Other]');
        $this->form_validation->set_rules('payment_status', 'Payment Status', 'permit_empty|in_list[Pending,Success,Failed,Refunded]');
        $this->form_validation->set_rules('reference_no', 'Reference No', 'permit_empty|max_length[100]');

        if ($this->form_validation->run() === FALSE) {
            return $this->respond_error('Validation failed.', self::HTTP_UNPROCESSABLE_ENTITY, $this->form_validation->error_array());
        }

        $order = $this->Order_model->find((int) $this->input('order_id'));
        if (!$order) {
            return $this->respond_error('Order not found.', self::HTTP_UNPROCESSABLE_ENTITY);
        }
        if ($order['order_status'] === 'Cancelled') {
            return $this->respond_error('Cannot record a payment against a cancelled order.', self::HTTP_BAD_REQUEST);
        }

        $this->db->trans_begin();
        try {
            $txnId = $this->Transaction_model->create(array(
                'txn_no'         => $this->Transaction_model->generate_txn_no(),
                'order_id'       => $order['id'],
                'customer_id'    => $order['customer_id'],
                'amount'         => (float) $this->input('amount'),
                'payment_method' => $this->input('payment_method', 'Cash'),
                'payment_status' => $this->input('payment_status', 'Success'),
                'reference_no'   => $this->input('reference_no'),
                'remarks'        => $this->input('remarks'),
                'created_at'     => date('Y-m-d H:i:s'),
            ));

            // Automatically recompute order.payment_status from all transactions
            $newStatus = $this->Order_model->recalculate_payment_status($order['id']);

            if ($this->db->trans_status() === FALSE) {
                throw new Exception('Transaction failed while recording payment.', self::HTTP_SERVER_ERROR);
            }
            $this->db->trans_commit();
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return $this->respond_error($e->getMessage(), $e->getCode() ?: self::HTTP_SERVER_ERROR);
        }

        $this->audit('transactions', 'create:' . $txnId);

        $result = $this->Transaction_model->find($txnId);
        $result['order_payment_status'] = $newStatus;
        $this->respond_success($result, 'Transaction recorded.', self::HTTP_CREATED);
    }
}
