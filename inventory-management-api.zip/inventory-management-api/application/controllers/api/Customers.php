<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Customers API — all authenticated roles can read/write.
 * GET    /api/customers
 * POST   /api/customers
 * GET    /api/customers/{id}
 * PUT    /api/customers/{id}
 * DELETE /api/customers/{id}
 */
class Customers extends Auth_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Customer_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $params = $this->get_list_params(array('id', 'name', 'mobile', 'created_at'), 'id');
        $result = $this->Customer_model->get_list($params);
        $this->respond_success($result['rows'], 'Customers fetched.', self::HTTP_OK, $this->build_meta($result['total'], $params));
    }

    public function view($id)
    {
        $customer = $this->Customer_model->find($id);
        if (!$customer) {
            return $this->respond_error('Customer not found.', self::HTTP_NOT_FOUND);
        }
        $this->respond_success($customer);
    }

    public function create()
    {
        $this->form_validation->set_data($this->payload);
        $this->form_validation->set_rules('name', 'Name', 'required|max_length[150]');
        $this->form_validation->set_rules('mobile', 'Mobile', 'required|regex_match[/^[0-9]{10}$/]');
        $this->form_validation->set_rules('email', 'Email', 'permit_empty|valid_email');
        $this->form_validation->set_rules('gst_no', 'GST No', 'permit_empty|max_length[20]');

        if ($this->form_validation->run() === FALSE) {
            return $this->respond_error('Validation failed.', self::HTTP_UNPROCESSABLE_ENTITY, $this->form_validation->error_array());
        }

        $mobile = trim($this->input('mobile'));
        if ($this->Customer_model->mobile_exists($mobile)) {
            return $this->respond_error('A customer with this mobile number already exists.', self::HTTP_UNPROCESSABLE_ENTITY);
        }

        $id = $this->Customer_model->create(array(
            'name'       => trim($this->input('name')),
            'mobile'     => $mobile,
            'email'      => $this->input('email'),
            'address'    => $this->input('address'),
            'gst_no'     => $this->input('gst_no'),
            'status'     => (int) $this->input('status', 1),
            'created_at' => date('Y-m-d H:i:s'),
        ));

        $this->audit('customers', 'create:' . $id);
        $this->respond_success($this->Customer_model->find($id), 'Customer created.', self::HTTP_CREATED);
    }

    public function update($id)
    {
        $customer = $this->Customer_model->find($id);
        if (!$customer) {
            return $this->respond_error('Customer not found.', self::HTTP_NOT_FOUND);
        }

        $this->form_validation->set_data($this->payload);
        $this->form_validation->set_rules('name', 'Name', 'permit_empty|max_length[150]');
        $this->form_validation->set_rules('mobile', 'Mobile', 'permit_empty|regex_match[/^[0-9]{10}$/]');
        $this->form_validation->set_rules('email', 'Email', 'permit_empty|valid_email');

        if ($this->form_validation->run() === FALSE) {
            return $this->respond_error('Validation failed.', self::HTTP_UNPROCESSABLE_ENTITY, $this->form_validation->error_array());
        }

        $data = array();
        if ($this->input('name') !== NULL) $data['name'] = trim($this->input('name'));
        if ($this->input('mobile') !== NULL) {
            $mobile = trim($this->input('mobile'));
            if ($this->Customer_model->mobile_exists($mobile, $id)) {
                return $this->respond_error('A customer with this mobile number already exists.', self::HTTP_UNPROCESSABLE_ENTITY);
            }
            $data['mobile'] = $mobile;
        }
        if ($this->input('email') !== NULL) $data['email'] = $this->input('email');
        if ($this->input('address') !== NULL) $data['address'] = $this->input('address');
        if ($this->input('gst_no') !== NULL) $data['gst_no'] = $this->input('gst_no');
        if ($this->input('status') !== NULL) $data['status'] = (int) $this->input('status');

        if (!empty($data)) {
            $this->Customer_model->update($id, $data);
            $this->audit('customers', 'update:' . $id);
        }

        $this->respond_success($this->Customer_model->find($id), 'Customer updated.');
    }

    public function delete($id)
    {
        $this->require_roles(array('Admin', 'Manager'));

        $customer = $this->Customer_model->find($id);
        if (!$customer) {
            return $this->respond_error('Customer not found.', self::HTTP_NOT_FOUND);
        }

        $this->Customer_model->delete($id);
        $this->audit('customers', 'delete:' . $id);
        $this->respond_success(NULL, 'Customer deleted.');
    }
}
