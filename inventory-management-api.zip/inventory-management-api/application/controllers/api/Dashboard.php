<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Dashboard API — summary counters + recent activity for a landing screen.
 * GET /api/dashboard
 */
class Dashboard extends Auth_Controller
{
    public function index()
    {
        $counts = array(
            'products'   => (int) $this->db->count_all('products'),
            'categories' => (int) $this->db->count_all('categories'),
            'customers'  => (int) $this->db->count_all('customers'),
            'orders'     => (int) $this->db->count_all('orders'),
        );

        $revenue = $this->db->select('COALESCE(SUM(grand_total),0) as total_revenue, COALESCE(SUM(paid_amount),0) as total_collected', FALSE)
            ->from('orders')
            ->where('order_status !=', 'Cancelled')
            ->get()->row_array();

        $pendingPayments = $this->db->select('COUNT(id) as count, COALESCE(SUM(grand_total - paid_amount),0) as amount_due', FALSE)
            ->from('orders')
            ->where_in('payment_status', array('Pending', 'Partial'))
            ->where('order_status !=', 'Cancelled')
            ->get()->row_array();

        $recentOrders = $this->db->select('orders.id, orders.order_no, orders.grand_total, orders.payment_status, orders.order_status, orders.created_at, customers.name as customer_name')
            ->from('orders')
            ->join('customers', 'customers.id = orders.customer_id', 'left')
            ->order_by('orders.id', 'desc')
            ->limit(5)
            ->get()->result_array();

        $lowStockCount = $this->db->from('products')
            ->where('stock <=', (int) $this->config->item('low_stock_threshold'))
            ->where('status', 1)
            ->count_all_results();

        $this->respond_success(array(
            'counts'           => $counts,
            'revenue'          => $revenue,
            'pending_payments' => $pendingPayments,
            'recent_orders'    => $recentOrders,
            'low_stock_count'  => (int) $lowStockCount,
        ), 'Dashboard summary fetched.');
    }
}
