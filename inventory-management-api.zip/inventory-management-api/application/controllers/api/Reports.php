<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Reports API — read-only aggregate endpoints.
 * GET /api/reports/sales       ?date_from=&date_to=
 * GET /api/reports/stock
 * GET /api/reports/low-stock
 * GET /api/reports/payments    ?date_from=&date_to=
 */
class Reports extends Auth_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Product_model');
    }

    public function sales()
    {
        $dateFrom = $this->input->get('date_from');
        $dateTo   = $this->input->get('date_to');

        $builder = $this->db->from('orders')->where('order_status !=', 'Cancelled');
        if ($dateFrom) $builder->where('created_at >=', $dateFrom . ' 00:00:00');
        if ($dateTo)   $builder->where('created_at <=', $dateTo . ' 23:59:59');

        $summary = $builder->select('
                COUNT(id) as total_orders,
                COALESCE(SUM(subtotal),0) as total_subtotal,
                COALESCE(SUM(tax),0) as total_tax,
                COALESCE(SUM(discount),0) as total_discount,
                COALESCE(SUM(grand_total),0) as total_revenue,
                COALESCE(SUM(paid_amount),0) as total_collected
            ', FALSE)
            ->get()->row_array();

        $byStatus = $this->db->select('order_status, COUNT(id) as count')
            ->from('orders')
            ->group_by('order_status')
            ->get()->result_array();

        $topProducts = $this->db->select('products.id, products.name, products.sku, SUM(order_items.qty) as total_qty_sold, SUM(order_items.amount) as total_amount')
            ->from('order_items')
            ->join('products', 'products.id = order_items.product_id')
            ->join('orders', 'orders.id = order_items.order_id')
            ->where('orders.order_status !=', 'Cancelled')
            ->group_by('products.id')
            ->order_by('total_qty_sold', 'desc')
            ->limit(5)
            ->get()->result_array();

        $this->respond_success(array(
            'summary'      => $summary,
            'by_status'    => $byStatus,
            'top_products' => $topProducts,
        ), 'Sales report generated.');
    }

    public function stock()
    {
        $rows = $this->db->select('products.id, products.sku, products.name, categories.name as category_name, products.stock, products.price, (products.stock * products.price) as stock_value')
            ->from('products')
            ->join('categories', 'categories.id = products.category_id', 'left')
            ->where('products.status', 1)
            ->order_by('products.stock', 'asc')
            ->get()->result_array();

        $totalValue = array_sum(array_column($rows, 'stock_value'));

        $this->respond_success(array(
            'products'          => $rows,
            'total_stock_value' => round($totalValue, 2),
        ), 'Stock report generated.');
    }

    public function low_stock()
    {
        $threshold = $this->input->get('threshold') ?: (int) $this->config->item('low_stock_threshold');
        $rows = $this->Product_model->low_stock($threshold);
        $this->respond_success(array('threshold' => (int) $threshold, 'products' => $rows), 'Low stock report generated.');
    }

    public function payments()
    {
        $dateFrom = $this->input->get('date_from');
        $dateTo   = $this->input->get('date_to');

        $builder = $this->db->from('transactions');
        if ($dateFrom) $builder->where('created_at >=', $dateFrom . ' 00:00:00');
        if ($dateTo)   $builder->where('created_at <=', $dateTo . ' 23:59:59');

        $byStatus = $builder->select('payment_status, COUNT(id) as count, COALESCE(SUM(amount),0) as total_amount')
            ->group_by('payment_status')
            ->get()->result_array();

        $byMethod = $this->db->select('payment_method, COUNT(id) as count, COALESCE(SUM(amount),0) as total_amount')
            ->from('transactions')
            ->where('payment_status', 'Success')
            ->group_by('payment_method')
            ->get()->result_array();

        $this->respond_success(array(
            'by_status' => $byStatus,
            'by_method' => $byMethod,
        ), 'Payments report generated.');
    }
}
