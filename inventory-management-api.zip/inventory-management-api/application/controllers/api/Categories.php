<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Categories API — read for all authenticated users, write for Admin/Manager.
 * GET    /api/categories
 * POST   /api/categories
 * GET    /api/categories/{id}
 * PUT    /api/categories/{id}
 * DELETE /api/categories/{id}
 */
class Categories extends Auth_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Category_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $params = $this->get_list_params(array('id', 'name', 'status', 'created_at'), 'id');
        $result = $this->Category_model->get_list($params);
        $this->respond_success($result['rows'], 'Categories fetched.', self::HTTP_OK, $this->build_meta($result['total'], $params));
    }

    public function view($id)
    {
        $category = $this->Category_model->find($id);
        if (!$category) {
            return $this->respond_error('Category not found.', self::HTTP_NOT_FOUND);
        }
        $this->respond_success($category);
    }

    public function create()
    {
        $this->require_roles(array('Admin', 'Manager'));

        $this->form_validation->set_data($this->payload);
        $this->form_validation->set_rules('name', 'Name', 'required|min_length[2]|max_length[100]');
        $this->form_validation->set_rules('description', 'Description', 'permit_empty|max_length[255]');
        $this->form_validation->set_rules('status', 'Status', 'permit_empty|in_list[0,1]');

        if ($this->form_validation->run() === FALSE) {
            return $this->respond_error('Validation failed.', self::HTTP_UNPROCESSABLE_ENTITY, $this->form_validation->error_array());
        }

        $name = trim($this->input('name'));
        if ($this->Category_model->name_exists($name)) {
            return $this->respond_error('A category with this name already exists.', self::HTTP_UNPROCESSABLE_ENTITY);
        }

        $id = $this->Category_model->create(array(
            'name'        => $name,
            'description' => $this->input('description'),
            'status'      => $this->input('status', 1),
            'created_at'  => date('Y-m-d H:i:s'),
        ));

        $this->audit('categories', 'create:' . $id);
        $this->respond_success($this->Category_model->find($id), 'Category created.', self::HTTP_CREATED);
    }

    public function update($id)
    {
        $this->require_roles(array('Admin', 'Manager'));

        $category = $this->Category_model->find($id);
        if (!$category) {
            return $this->respond_error('Category not found.', self::HTTP_NOT_FOUND);
        }

        $this->form_validation->set_data($this->payload);
        $this->form_validation->set_rules('name', 'Name', 'permit_empty|min_length[2]|max_length[100]');
        $this->form_validation->set_rules('description', 'Description', 'permit_empty|max_length[255]');
        $this->form_validation->set_rules('status', 'Status', 'permit_empty|in_list[0,1]');

        if ($this->form_validation->run() === FALSE) {
            return $this->respond_error('Validation failed.', self::HTTP_UNPROCESSABLE_ENTITY, $this->form_validation->error_array());
        }

        $data = array();
        if ($this->input('name') !== NULL) {
            $name = trim($this->input('name'));
            if ($this->Category_model->name_exists($name, $id)) {
                return $this->respond_error('A category with this name already exists.', self::HTTP_UNPROCESSABLE_ENTITY);
            }
            $data['name'] = $name;
        }
        if ($this->input('description') !== NULL) $data['description'] = $this->input('description');
        if ($this->input('status') !== NULL) $data['status'] = (int) $this->input('status');

        if (!empty($data)) {
            $this->Category_model->update($id, $data);
            $this->audit('categories', 'update:' . $id);
        }

        $this->respond_success($this->Category_model->find($id), 'Category updated.');
    }

    public function delete($id)
    {
        $this->require_roles(array('Admin', 'Manager'));

        $category = $this->Category_model->find($id);
        if (!$category) {
            return $this->respond_error('Category not found.', self::HTTP_NOT_FOUND);
        }

        if ($this->Category_model->is_in_use($id)) {
            return $this->respond_error('Cannot delete a category that has products assigned to it.', self::HTTP_BAD_REQUEST);
        }

        $this->Category_model->delete($id);
        $this->audit('categories', 'delete:' . $id);
        $this->respond_success(NULL, 'Category deleted.');
    }
}
