<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Stock Ledger API — read-only movement history + manual adjustments.
 * GET  /api/stock-ledger                    ?reference_type=&page=&limit=&order=
 * GET  /api/stock-ledger/product/{id}       ?page=&limit=
 * POST /api/stock-ledger/adjust              { product_id, quantity, remarks }  (Admin/Manager only)
 */
class Stock_ledger extends Auth_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('StockLedger_model');
        $this->load->model('Product_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $params = $this->get_list_params(array('id', 'created_at'), 'id');
        $params['reference_type'] = $this->input->get('reference_type');

        $result = $this->StockLedger_model->get_list($params);
        $this->respond_success($result['rows'], 'Stock ledger fetched.', self::HTTP_OK, $this->build_meta($result['total'], $params));
    }

    public function by_product($productId)
    {
        $product = $this->Product_model->find($productId);
        if (!$product) {
            return $this->respond_error('Product not found.', self::HTTP_NOT_FOUND);
        }

        $params = $this->get_list_params(array('id'), 'id');
        $result = $this->StockLedger_model->get_by_product($productId, $params);

        $this->respond_success(array(
            'product' => array('id' => $product['id'], 'sku' => $product['sku'], 'name' => $product['name'], 'current_stock' => $product['stock']),
            'ledger'  => $result['rows'],
        ), 'Product stock ledger fetched.', self::HTTP_OK, $this->build_meta($result['total'], $params));
    }

    /**
     * Manual stock adjustment (e.g. stock take corrections, damages, new
     * purchases entered outside the order flow). Positive quantity = stock
     * in, negative quantity = stock out.
     */
    public function adjust()
    {
        $this->require_roles(array('Admin', 'Manager'));

        $this->form_validation->set_data($this->payload);
        $this->form_validation->set_rules('product_id', 'Product', 'required|integer');
        $this->form_validation->set_rules('quantity', 'Quantity', 'required|integer');
        $this->form_validation->set_rules('remarks', 'Remarks', 'permit_empty|max_length[255]');

        if ($this->form_validation->run() === FALSE) {
            return $this->respond_error('Validation failed.', self::HTTP_UNPROCESSABLE_ENTITY, $this->form_validation->error_array());
        }

        $qty = (int) $this->input('quantity');
        if ($qty === 0) {
            return $this->respond_error('Quantity must not be zero.', self::HTTP_UNPROCESSABLE_ENTITY);
        }

        $this->db->trans_begin();
        try {
            $product = $this->Product_model->lock_for_update((int) $this->input('product_id'));
            if (!$product) {
                throw new Exception('Product not found.', self::HTTP_NOT_FOUND);
            }

            $newStock = (int) $product['stock'] + $qty;
            if ($newStock < 0) {
                throw new Exception('Adjustment would result in negative stock. Current stock: ' . $product['stock'], self::HTTP_BAD_REQUEST);
            }

            $this->Product_model->adjust_stock($product['id'], $qty);

            $this->StockLedger_model->record(
                $product['id'],
                'ADJUSTMENT',
                NULL,
                $qty > 0 ? $qty : 0,
                $qty < 0 ? abs($qty) : 0,
                $newStock,
                $this->input('remarks', 'Manual stock adjustment')
            );

            if ($this->db->trans_status() === FALSE) {
                throw new Exception('Transaction failed while adjusting stock.', self::HTTP_SERVER_ERROR);
            }
            $this->db->trans_commit();
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return $this->respond_error($e->getMessage(), $e->getCode() ?: self::HTTP_SERVER_ERROR);
        }

        $this->audit('stock_ledger', 'adjust:' . $product['id']);
        $this->respond_success($this->Product_model->find($product['id']), 'Stock adjusted.', self::HTTP_CREATED);
    }
}
