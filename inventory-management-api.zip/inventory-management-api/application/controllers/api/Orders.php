<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Orders API
 * GET  /api/orders                    ?search=&order_status=&payment_status=&customer_id=&date_from=&date_to=&page=&limit=&sort=&order=
 * POST /api/orders                     { customer_id, tax, discount, items:[{product_id, qty}] }
 * GET  /api/orders/{id}
 * PUT  /api/orders/{id}/status         { order_status: Processing|Completed }
 * PUT  /api/orders/{id}/cancel
 */
class Orders extends Auth_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Order_model');
        $this->load->model('Product_model');
        $this->load->model('Customer_model');
        $this->load->model('StockLedger_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $params = $this->get_list_params(array('id', 'order_no', 'grand_total', 'created_at'), 'created_at');
        $params['order_status']   = $this->input->get('order_status');
        $params['payment_status'] = $this->input->get('payment_status');
        $params['customer_id']    = $this->input->get('customer_id');
        $params['date_from']      = $this->input->get('date_from');
        $params['date_to']        = $this->input->get('date_to');

        $result = $this->Order_model->get_list($params);
        $this->respond_success($result['rows'], 'Orders fetched.', self::HTTP_OK, $this->build_meta($result['total'], $params));
    }

    public function view($id)
    {
        $order = $this->Order_model->find($id);
        if (!$order) {
            return $this->respond_error('Order not found.', self::HTTP_NOT_FOUND);
        }
        $order['items'] = $this->Order_model->get_items($id);
        $this->respond_success($order);
    }

    /**
     * Create a new order with multiple items.
     * Business rules enforced here:
     *   - stock is validated (and row-locked) BEFORE any write occurs
     *   - the whole operation runs inside a single DB transaction
     *   - stock is only deducted once the order is successfully persisted
     *   - every stock movement is written to stock_ledger for audit trail
     */
    public function create()
    {
        $this->form_validation->set_data($this->payload);
        $this->form_validation->set_rules('customer_id', 'Customer', 'required|integer');
        $this->form_validation->set_rules('items', 'Items', 'required');
        $this->form_validation->set_rules('tax', 'Tax', 'permit_empty|decimal|greater_than_equal_to[0]');
        $this->form_validation->set_rules('discount', 'Discount', 'permit_empty|decimal|greater_than_equal_to[0]');

        if ($this->form_validation->run() === FALSE) {
            return $this->respond_error('Validation failed.', self::HTTP_UNPROCESSABLE_ENTITY, $this->form_validation->error_array());
        }

        $items = $this->input('items');
        if (!is_array($items) || count($items) === 0) {
            return $this->respond_error('Order must contain at least one item.', self::HTTP_UNPROCESSABLE_ENTITY);
        }

        $customer = $this->Customer_model->find((int) $this->input('customer_id'));
        if (!$customer) {
            return $this->respond_error('Selected customer does not exist.', self::HTTP_UNPROCESSABLE_ENTITY);
        }

        // Basic structural validation of each item before touching the DB
        foreach ($items as $i => $item) {
            if (empty($item['product_id']) || !is_numeric($item['product_id'])) {
                return $this->respond_error("Item #" . ($i + 1) . ": product_id is required.", self::HTTP_UNPROCESSABLE_ENTITY);
            }
            if (empty($item['qty']) || !is_numeric($item['qty']) || (int) $item['qty'] <= 0) {
                return $this->respond_error("Item #" . ($i + 1) . ": qty must be a positive integer.", self::HTTP_UNPROCESSABLE_ENTITY);
            }
        }

        $tax = (float) $this->input('tax', 0);
        $discount = (float) $this->input('discount', 0);

        $this->db->trans_begin();

        try {
            $subtotal = 0;
            $preparedItems = array();

            // Merge duplicate product_id entries so we only lock each row once
            $merged = array();
            foreach ($items as $item) {
                $pid = (int) $item['product_id'];
                $qty = (int) $item['qty'];
                $merged[$pid] = isset($merged[$pid]) ? $merged[$pid] + $qty : $qty;
            }

            foreach ($merged as $productId => $qty) {
                $product = $this->Product_model->lock_for_update($productId);

                if (!$product) {
                    throw new Exception("Product ID {$productId} not found.", self::HTTP_UNPROCESSABLE_ENTITY);
                }
                if ((int) $product['status'] !== 1) {
                    throw new Exception("Product '{$product['name']}' is inactive and cannot be ordered.", self::HTTP_UNPROCESSABLE_ENTITY);
                }
                if ((int) $product['stock'] < $qty) {
                    throw new Exception(
                        "Insufficient stock for '{$product['name']}'. Available: {$product['stock']}, Requested: {$qty}.",
                        self::HTTP_BAD_REQUEST
                    );
                }

                $price = (float) $product['price'];
                $amount = round($price * $qty, 2);
                $subtotal += $amount;

                $preparedItems[] = array(
                    'product_id' => $productId,
                    'qty'        => $qty,
                    'price'      => $price,
                    'amount'     => $amount,
                    'name'       => $product['name'],
                    'current_stock' => (int) $product['stock'],
                );
            }

            $grandTotal = max(0, round($subtotal + $tax - $discount, 2));

            $orderId = $this->Order_model->create(array(
                'order_no'       => $this->Order_model->generate_order_no(),
                'customer_id'    => $customer['id'],
                'subtotal'       => $subtotal,
                'tax'            => $tax,
                'discount'       => $discount,
                'grand_total'    => $grandTotal,
                'paid_amount'    => 0,
                'payment_status' => 'Pending',
                'order_status'   => 'New',
                'created_by'     => $this->auth_user_id,
                'created_at'     => date('Y-m-d H:i:s'),
            ));

            foreach ($preparedItems as $item) {
                $this->Order_model->add_item(array(
                    'order_id'   => $orderId,
                    'product_id' => $item['product_id'],
                    'qty'        => $item['qty'],
                    'price'      => $item['price'],
                    'amount'     => $item['amount'],
                ));

                // Deduct stock only now that the order row exists
                $this->Product_model->adjust_stock($item['product_id'], -$item['qty']);
                $newBalance = $item['current_stock'] - $item['qty'];

                $this->StockLedger_model->record(
                    $item['product_id'],
                    'ORDER',
                    $orderId,
                    0,
                    $item['qty'],
                    $newBalance,
                    'Stock deducted for order #' . $orderId
                );
            }

            if ($this->db->trans_status() === FALSE) {
                throw new Exception('Transaction failed while creating the order.', self::HTTP_SERVER_ERROR);
            }

            $this->db->trans_commit();
        } catch (Exception $e) {
            $this->db->trans_rollback();
            $code = $e->getCode() ?: self::HTTP_BAD_REQUEST;
            return $this->respond_error($e->getMessage(), $code);
        }

        $this->audit('orders', 'create:' . $orderId);

        $order = $this->Order_model->find($orderId);
        $order['items'] = $this->Order_model->get_items($orderId);
        $this->respond_success($order, 'Order created successfully.', self::HTTP_CREATED);
    }

    /**
     * Advance order workflow status (does NOT affect stock or payments).
     * Use /orders/{id}/cancel to cancel an order (handles restocking).
     */
    public function update_status($id)
    {
        $this->require_roles(array('Admin', 'Manager', 'Staff'));

        $order = $this->Order_model->find($id);
        if (!$order) {
            return $this->respond_error('Order not found.', self::HTTP_NOT_FOUND);
        }
        if ($order['order_status'] === 'Cancelled') {
            return $this->respond_error('Cannot change status of a cancelled order.', self::HTTP_BAD_REQUEST);
        }

        $this->form_validation->set_data($this->payload);
        $this->form_validation->set_rules('order_status', 'Order Status', 'required|in_list[Processing,Completed]');

        if ($this->form_validation->run() === FALSE) {
            return $this->respond_error('Validation failed.', self::HTTP_UNPROCESSABLE_ENTITY, $this->form_validation->error_array());
        }

        $this->Order_model->update($id, array('order_status' => $this->input('order_status')));
        $this->audit('orders', 'status_update:' . $id);

        $this->respond_success($this->Order_model->find($id), 'Order status updated.');
    }

    /**
     * Cancel an order: restores stock for every item and writes a
     * CANCELLATION entry to the stock ledger, all inside one transaction.
     */
    public function cancel($id)
    {
        $this->require_roles(array('Admin', 'Manager'));

        $order = $this->Order_model->find($id);
        if (!$order) {
            return $this->respond_error('Order not found.', self::HTTP_NOT_FOUND);
        }
        if ($order['order_status'] === 'Cancelled') {
            return $this->respond_error('Order is already cancelled.', self::HTTP_BAD_REQUEST);
        }
        if ($order['order_status'] === 'Completed') {
            return $this->respond_error('Cannot cancel a completed order.', self::HTTP_BAD_REQUEST);
        }

        $items = $this->Order_model->get_items($id);

        $this->db->trans_begin();
        try {
            foreach ($items as $item) {
                $product = $this->Product_model->lock_for_update($item['product_id']);
                if (!$product) {
                    continue; // product may have been removed; skip restock gracefully
                }
                $this->Product_model->adjust_stock($item['product_id'], (int) $item['qty']);
                $newBalance = (int) $product['stock'] + (int) $item['qty'];

                $this->StockLedger_model->record(
                    $item['product_id'],
                    'CANCELLATION',
                    $id,
                    (int) $item['qty'],
                    0,
                    $newBalance,
                    'Stock restored — order #' . $id . ' cancelled'
                );
            }

            $this->Order_model->update($id, array('order_status' => 'Cancelled'));

            if ($this->db->trans_status() === FALSE) {
                throw new Exception('Transaction failed while cancelling the order.', self::HTTP_SERVER_ERROR);
            }
            $this->db->trans_commit();
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return $this->respond_error($e->getMessage(), $e->getCode() ?: self::HTTP_SERVER_ERROR);
        }

        $this->audit('orders', 'cancel:' . $id);
        $this->respond_success($this->Order_model->find($id), 'Order cancelled and stock restored.');
    }
}
