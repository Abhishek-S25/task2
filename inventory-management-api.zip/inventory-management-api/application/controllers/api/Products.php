<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Products API — read for all authenticated users, write for Admin/Manager.
 * GET    /api/products              ?search=&category_id=&status=&page=&limit=&sort=&order=
 * POST   /api/products               (multipart/form-data, optional `image` file)
 * GET    /api/products/{id}
 * PUT|POST /api/products/{id}        (multipart/form-data for image replace)
 * DELETE /api/products/{id}
 */
class Products extends Auth_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Product_model');
        $this->load->model('Category_model');
        $this->load->library('form_validation');
        $this->load->helper('url');
    }

    public function index()
    {
        $params = $this->get_list_params(array('id', 'name', 'sku', 'price', 'stock', 'created_at'), 'id');
        $params['category_id'] = $this->input->get('category_id');
        $params['status'] = $this->input->get('status');

        $result = $this->Product_model->get_list($params);
        $rows = array_map(array($this, 'decorate_image'), $result['rows']);

        $this->respond_success($rows, 'Products fetched.', self::HTTP_OK, $this->build_meta($result['total'], $params));
    }

    public function view($id)
    {
        $product = $this->Product_model->find($id);
        if (!$product) {
            return $this->respond_error('Product not found.', self::HTTP_NOT_FOUND);
        }
        $this->respond_success($this->decorate_image($product));
    }

    public function create()
    {
        $this->require_roles(array('Admin', 'Manager'));

        $this->form_validation->set_data($this->payload);
        $this->form_validation->set_rules('category_id', 'Category', 'required|integer');
        $this->form_validation->set_rules('sku', 'SKU', 'required|max_length[50]');
        $this->form_validation->set_rules('name', 'Name', 'required|max_length[150]');
        $this->form_validation->set_rules('price', 'Price', 'required|decimal|greater_than_equal_to[0]');
        $this->form_validation->set_rules('stock', 'Stock', 'permit_empty|integer|greater_than_equal_to[0]');

        if ($this->form_validation->run() === FALSE) {
            return $this->respond_error('Validation failed.', self::HTTP_UNPROCESSABLE_ENTITY, $this->form_validation->error_array());
        }

        if (!$this->Category_model->find($this->input('category_id'))) {
            return $this->respond_error('Selected category does not exist.', self::HTTP_UNPROCESSABLE_ENTITY);
        }

        $sku = trim($this->input('sku'));
        if ($this->Product_model->sku_exists($sku)) {
            return $this->respond_error('A product with this SKU already exists.', self::HTTP_UNPROCESSABLE_ENTITY);
        }

        $imageName = NULL;
        if (!empty($_FILES['image']['name'])) {
            $uploadResult = $this->handle_image_upload();
            if ($uploadResult['error']) {
                return $this->respond_error($uploadResult['error'], self::HTTP_UNPROCESSABLE_ENTITY);
            }
            $imageName = $uploadResult['file_name'];
        }

        $id = $this->Product_model->create(array(
            'category_id' => (int) $this->input('category_id'),
            'sku'         => $sku,
            'name'        => trim($this->input('name')),
            'description' => $this->input('description'),
            'image'       => $imageName,
            'price'       => (float) $this->input('price'),
            'stock'       => (int) $this->input('stock', 0),
            'status'      => (int) $this->input('status', 1),
            'created_at'  => date('Y-m-d H:i:s'),
        ));

        $this->audit('products', 'create:' . $id);
        $this->respond_success($this->decorate_image($this->Product_model->find($id)), 'Product created.', self::HTTP_CREATED);
    }

    public function update($id)
    {
        $this->require_roles(array('Admin', 'Manager'));

        $product = $this->Product_model->find($id);
        if (!$product) {
            return $this->respond_error('Product not found.', self::HTTP_NOT_FOUND);
        }

        $this->form_validation->set_data($this->payload);
        $this->form_validation->set_rules('category_id', 'Category', 'permit_empty|integer');
        $this->form_validation->set_rules('sku', 'SKU', 'permit_empty|max_length[50]');
        $this->form_validation->set_rules('name', 'Name', 'permit_empty|max_length[150]');
        $this->form_validation->set_rules('price', 'Price', 'permit_empty|decimal|greater_than_equal_to[0]');
        $this->form_validation->set_rules('stock', 'Stock', 'permit_empty|integer|greater_than_equal_to[0]');

        if ($this->form_validation->run() === FALSE) {
            return $this->respond_error('Validation failed.', self::HTTP_UNPROCESSABLE_ENTITY, $this->form_validation->error_array());
        }

        $data = array();

        if ($this->input('category_id') !== NULL) {
            if (!$this->Category_model->find($this->input('category_id'))) {
                return $this->respond_error('Selected category does not exist.', self::HTTP_UNPROCESSABLE_ENTITY);
            }
            $data['category_id'] = (int) $this->input('category_id');
        }
        if ($this->input('sku') !== NULL) {
            $sku = trim($this->input('sku'));
            if ($this->Product_model->sku_exists($sku, $id)) {
                return $this->respond_error('A product with this SKU already exists.', self::HTTP_UNPROCESSABLE_ENTITY);
            }
            $data['sku'] = $sku;
        }
        if ($this->input('name') !== NULL) $data['name'] = trim($this->input('name'));
        if ($this->input('description') !== NULL) $data['description'] = $this->input('description');
        if ($this->input('price') !== NULL) $data['price'] = (float) $this->input('price');
        if ($this->input('status') !== NULL) $data['status'] = (int) $this->input('status');
        // NOTE: stock is intentionally NOT editable here directly — it must
        // only change via orders or the stock-ledger adjustment endpoint so
        // every movement is auditable.

        if (!empty($_FILES['image']['name'])) {
            $uploadResult = $this->handle_image_upload();
            if ($uploadResult['error']) {
                return $this->respond_error($uploadResult['error'], self::HTTP_UNPROCESSABLE_ENTITY);
            }
            // remove old image file
            if (!empty($product['image'])) {
                $oldPath = $this->config->item('upload_path') . $product['image'];
                if (is_file($oldPath)) { @unlink($oldPath); }
            }
            $data['image'] = $uploadResult['file_name'];
        }

        if (!empty($data)) {
            $data['updated_at'] = date('Y-m-d H:i:s');
            $this->Product_model->update($id, $data);
            $this->audit('products', 'update:' . $id);
        }

        $this->respond_success($this->decorate_image($this->Product_model->find($id)), 'Product updated.');
    }

    public function delete($id)
    {
        $this->require_roles(array('Admin', 'Manager'));

        $product = $this->Product_model->find($id);
        if (!$product) {
            return $this->respond_error('Product not found.', self::HTTP_NOT_FOUND);
        }

        $this->Product_model->delete($id);
        $this->audit('products', 'delete:' . $id);
        $this->respond_success(NULL, 'Product deleted.');
    }

    /**
     * Handles a single `image` file upload using CI's native upload library.
     * Returns array('file_name' => string|NULL, 'error' => string|NULL)
     */
    private function handle_image_upload()
    {
        $config['upload_path']   = $this->config->item('upload_path');
        $config['allowed_types'] = $this->config->item('upload_allowed_types');
        $config['max_size']      = $this->config->item('upload_max_size');
        $config['encrypt_name']  = TRUE;

        if (!is_dir($config['upload_path'])) {
            @mkdir($config['upload_path'], 0755, TRUE);
        }

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('image')) {
            return array('file_name' => NULL, 'error' => $this->upload->display_errors('', ''));
        }

        $data = $this->upload->data();
        return array('file_name' => $data['file_name'], 'error' => NULL);
    }

    private function decorate_image($product)
    {
        if (!empty($product['image'])) {
            $product['image_url'] = base_url('uploads/products/' . $product['image']);
        } else {
            $product['image_url'] = NULL;
        }
        return $product;
    }
}
