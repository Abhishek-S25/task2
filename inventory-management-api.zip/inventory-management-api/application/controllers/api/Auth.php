<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Auth API
 * POST /api/auth/login  - public, returns a JWT access token
 * POST /api/auth/logout - stateless: client just discards the token
 * GET  /api/auth/me     - returns the authenticated user's profile
 */
class Auth extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->library('Jwt');
        $this->load->library('Auditor');
        $this->load->library('form_validation');
    }

    public function login()
    {
        $this->form_validation->set_data($this->payload);
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');

        if ($this->form_validation->run() === FALSE) {
            return $this->respond_error(
                'Validation failed.',
                self::HTTP_UNPROCESSABLE_ENTITY,
                $this->form_validation->error_array()
            );
        }

        $email = trim($this->input('email'));
        $password = (string) $this->input('password');

        $user = $this->User_model->find_by_email($email);

        if (!$user || !password_verify($password, $user['password'])) {
            return $this->respond_error('Invalid email or password.', self::HTTP_UNAUTHORIZED);
        }

        if ((int) $user['status'] !== 1) {
            return $this->respond_error('Your account has been deactivated. Contact the administrator.', self::HTTP_FORBIDDEN);
        }

        $token = $this->jwt->encode(array(
            'uid'       => (int) $user['id'],
            'role_id'   => (int) $user['role_id'],
            'role_name' => $user['role_name'],
            'email'     => $user['email'],
        ));

        $this->auditor->log($user['id'], 'auth', 'login');

        return $this->respond_success(array(
            'token'      => $token,
            'token_type' => 'Bearer',
            'expires_in' => (int) $this->config->item('jwt_expiry'),
            'user'       => array(
                'id'    => (int) $user['id'],
                'name'  => $user['name'],
                'email' => $user['email'],
                'role'  => $user['role_name'],
            ),
        ), 'Login successful.');
    }

    public function logout()
    {
        // JWTs are stateless; nothing is stored server-side to revoke.
        // A production system could maintain a token blacklist/Redis set here.
        return $this->respond_success(NULL, 'Logged out successfully. Please discard the token client-side.');
    }

    public function me()
    {
        $token = $this->get_bearer_token_public();
        $payload = $token ? $this->jwt->decode($token) : FALSE;

        if (!$payload) {
            return $this->respond_error('Invalid or expired token.', self::HTTP_UNAUTHORIZED);
        }

        $user = $this->User_model->find((int) $payload['uid']);
        if (!$user) {
            return $this->respond_error('User not found.', self::HTTP_NOT_FOUND);
        }

        unset($user['password']);
        return $this->respond_success($user);
    }

    private function get_bearer_token_public()
    {
        $header = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
        if (preg_match('/Bearer\s+(\S+)/i', $header, $m)) {
            return $m[1];
        }
        return NULL;
    }
}
