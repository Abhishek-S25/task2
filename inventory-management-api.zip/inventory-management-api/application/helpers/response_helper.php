<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Build a standard success response envelope.
 */
if (!function_exists('success_response')) {
    function success_response($data = NULL, $message = 'Success', $meta = NULL)
    {
        $res = array(
            'status'  => TRUE,
            'message' => $message,
            'data'    => $data,
        );
        if ($meta !== NULL) {
            $res['meta'] = $meta;
        }
        return $res;
    }
}

/**
 * Build a standard error response envelope.
 */
if (!function_exists('error_response')) {
    function error_response($message = 'Something went wrong', $errors = NULL)
    {
        $res = array(
            'status'  => FALSE,
            'message' => $message,
        );
        if ($errors !== NULL) {
            $res['errors'] = $errors;
        }
        return $res;
    }
}
