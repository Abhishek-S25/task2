<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Auth_Controller
 * ----------------
 * Base controller for every protected API endpoint.
 *
 * Responsibilities:
 *  - Requires a valid `Authorization: Bearer <jwt>` header on every request.
 *  - Decodes the token and exposes the authenticated user as:
 *        $this->auth_user_id
 *        $this->auth_role_id
 *        $this->auth_role_name
 *        $this->auth_email
 *  - Provides require_roles() for simple role-based access control.
 *  - Writes an audit_logs entry for every mutating (POST/PUT/DELETE) call
 *    via the Auditor library.
 */
class Auth_Controller extends REST_Controller
{
    protected $auth_user_id;
    protected $auth_role_id;
    protected $auth_role_name;
    protected $auth_email;

    public function __construct()
    {
        parent::__construct();

        $this->load->library('Jwt');
        $this->load->library('Auditor');

        $token = $this->get_bearer_token();

        if (empty($token)) {
            $this->respond_error('Authorization token missing.', self::HTTP_UNAUTHORIZED);
            exit;
        }

        $payload = $this->jwt->decode($token);

        if ($payload === FALSE) {
            $this->respond_error('Invalid or expired token.', self::HTTP_UNAUTHORIZED);
            exit;
        }

        $this->auth_user_id   = isset($payload['uid']) ? (int) $payload['uid'] : NULL;
        $this->auth_role_id   = isset($payload['role_id']) ? (int) $payload['role_id'] : NULL;
        $this->auth_role_name = isset($payload['role_name']) ? $payload['role_name'] : NULL;
        $this->auth_email     = isset($payload['email']) ? $payload['email'] : NULL;

        if (empty($this->auth_user_id)) {
            $this->respond_error('Invalid token payload.', self::HTTP_UNAUTHORIZED);
            exit;
        }
    }

    protected function get_bearer_token()
    {
        $header = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';

        if (empty($header) && function_exists('apache_request_headers')) {
            $headers = apache_request_headers();
            if (isset($headers['Authorization'])) {
                $header = $headers['Authorization'];
            }
        }

        if (preg_match('/Bearer\s+(\S+)/i', $header, $matches)) {
            return $matches[1];
        }

        return NULL;
    }

    /**
     * Restrict the current action to specific role names.
     * Call at the top of a controller method, e.g.:
     *   $this->require_roles(array('Admin'));
     */
    protected function require_roles(array $allowedRoles)
    {
        if (!in_array($this->auth_role_name, $allowedRoles, TRUE)) {
            $this->respond_error(
                'You do not have permission to perform this action.',
                self::HTTP_FORBIDDEN
            );
            exit;
        }
    }

    /**
     * Convenience wrapper to log an action to audit_logs.
     */
    protected function audit($module, $action)
    {
        $this->auditor->log($this->auth_user_id, $module, $action);
    }
}
