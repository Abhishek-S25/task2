<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auditor
{
    protected $CI;

    public function __construct()
    {
        $this->CI =& get_instance();
        $this->CI->load->database();
    }

    /**
     * Insert a row into audit_logs. Never throws — a failed audit write
     * should not break the primary request.
     */
    public function log($userId, $module, $action)
    {
        try {
            $this->CI->db->insert('audit_logs', array(
                'user_id'    => $userId,
                'module'     => $module,
                'action'     => $action,
                'ip_address' => $this->CI->input->ip_address(),
                'created_at' => date('Y-m-d H:i:s'),
            ));
        } catch (Exception $e) {
            log_message('error', 'Audit log failed: ' . $e->getMessage());
        }
    }
}
