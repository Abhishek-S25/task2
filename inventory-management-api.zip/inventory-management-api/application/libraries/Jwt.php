<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Minimal, dependency-free JWT (HS256) library for CodeIgniter 3.
 *
 * Implements just enough of RFC 7519 for stateless API authentication:
 *  - encode(array $payload): string
 *  - decode(string $token): array|FALSE
 *
 * No composer / external package required.
 */
class Jwt
{
    protected $secret;
    protected $algo = 'sha256';
    protected $expiry;

    public function __construct()
    {
        $CI =& get_instance();
        $this->secret = $CI->config->item('jwt_secret');
        $this->expiry = (int) $CI->config->item('jwt_expiry');

        if (empty($this->secret)) {
            $this->secret = 'fallback-secret-change-me';
        }
    }

    protected function base64UrlEncode($data)
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    protected function base64UrlDecode($data)
    {
        $remainder = strlen($data) % 4;
        if ($remainder) {
            $data .= str_repeat('=', 4 - $remainder);
        }
        return base64_decode(strtr($data, '-_', '+/'));
    }

    /**
     * Encode a payload array into a signed JWT string.
     *
     * @param array $payload
     * @return string
     */
    public function encode(array $payload)
    {
        $header = array('typ' => 'JWT', 'alg' => 'HS256');

        $now = time();
        $payload['iat'] = $now;
        $payload['exp'] = $now + $this->expiry;

        $segments   = array();
        $segments[] = $this->base64UrlEncode(json_encode($header));
        $segments[] = $this->base64UrlEncode(json_encode($payload));

        $signingInput = implode('.', $segments);
        $signature = hash_hmac($this->algo, $signingInput, $this->secret, TRUE);
        $segments[] = $this->base64UrlEncode($signature);

        return implode('.', $segments);
    }

    /**
     * Decode & verify a JWT string.
     *
     * @param string $token
     * @return array|FALSE  Decoded payload array, or FALSE on failure.
     */
    public function decode($token)
    {
        if (empty($token) || substr_count($token, '.') !== 2) {
            return FALSE;
        }

        list($headerB64, $payloadB64, $sigB64) = explode('.', $token);

        $header = json_decode($this->base64UrlDecode($headerB64), TRUE);
        $payload = json_decode($this->base64UrlDecode($payloadB64), TRUE);
        $signature = $this->base64UrlDecode($sigB64);

        if (!$header || !$payload || !isset($header['alg']) || $header['alg'] !== 'HS256') {
            return FALSE;
        }

        $signingInput = $headerB64 . '.' . $payloadB64;
        $expectedSig = hash_hmac($this->algo, $signingInput, $this->secret, TRUE);

        if (!hash_equals($expectedSig, $signature)) {
            return FALSE; // tampered or invalid
        }

        if (isset($payload['exp']) && time() >= $payload['exp']) {
            return FALSE; // expired
        }

        return $payload;
    }
}
