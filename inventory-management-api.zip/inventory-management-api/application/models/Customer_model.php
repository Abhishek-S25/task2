<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer_model extends CI_Model
{
    protected $table = 'customers';

    public function get_list($params)
    {
        $count = $this->db->from($this->table);
        if (!empty($params['search'])) {
            $count->group_start()
                ->like('name', $params['search'])
                ->or_like('mobile', $params['search'])
                ->or_like('email', $params['search'])
                ->group_end();
        }
        $total = $count->count_all_results();

        $rows = $this->db->from($this->table);
        if (!empty($params['search'])) {
            $rows->group_start()
                ->like('name', $params['search'])
                ->or_like('mobile', $params['search'])
                ->or_like('email', $params['search'])
                ->group_end();
        }
        $rows->order_by($params['sort'], $params['order']);
        $rows->limit($params['limit'], $params['offset']);

        return array('rows' => $rows->get()->result_array(), 'total' => $total);
    }

    public function find($id)
    {
        return $this->db->where('id', $id)->get($this->table)->row_array();
    }

    public function mobile_exists($mobile, $excludeId = NULL)
    {
        $this->db->where('mobile', $mobile);
        if ($excludeId) {
            $this->db->where('id !=', $excludeId);
        }
        return $this->db->get($this->table)->num_rows() > 0;
    }

    public function create($data)
    {
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    public function update($id, $data)
    {
        return $this->db->where('id', $id)->update($this->table, $data);
    }

    public function delete($id)
    {
        return $this->db->where('id', $id)->delete($this->table);
    }
}
