<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model
{
    protected $table = 'users';

    public function find_by_email($email)
    {
        return $this->db->select('users.*, roles.name as role_name')
            ->from($this->table)
            ->join('roles', 'roles.id = users.role_id')
            ->where('users.email', $email)
            ->get()
            ->row_array();
    }

    public function find($id)
    {
        return $this->db->select('users.*, roles.name as role_name')
            ->from($this->table)
            ->join('roles', 'roles.id = users.role_id')
            ->where('users.id', $id)
            ->get()
            ->row_array();
    }
}
