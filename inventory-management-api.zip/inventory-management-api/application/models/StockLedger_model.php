<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class StockLedger_model extends CI_Model
{
    protected $table = 'stock_ledger';

    /**
     * Insert a ledger entry. $balanceStock must be the product's stock
     * value AFTER the movement has been applied, computed by the caller
     * inside the same DB transaction to guarantee an accurate audit trail.
     */
    public function record($productId, $referenceType, $referenceId, $stockIn, $stockOut, $balanceStock, $remarks = NULL)
    {
        return $this->db->insert($this->table, array(
            'product_id'     => $productId,
            'reference_type' => $referenceType,
            'reference_id'   => $referenceId,
            'stock_in'       => $stockIn,
            'stock_out'      => $stockOut,
            'balance_stock'  => $balanceStock,
            'remarks'        => $remarks,
            'created_at'     => date('Y-m-d H:i:s'),
        ));
    }

    public function get_by_product($productId, $params)
    {
        $count = $this->db->from($this->table)->where('product_id', $productId);
        $total = $count->count_all_results();

        $rows = $this->db->from($this->table)
            ->where('product_id', $productId)
            ->order_by('id', 'desc')
            ->limit($params['limit'], $params['offset'])
            ->get()
            ->result_array();

        return array('rows' => $rows, 'total' => $total);
    }

    public function get_list($params)
    {
        $count = $this->db->from($this->table);
        if (!empty($params['reference_type'])) {
            $count->where('reference_type', $params['reference_type']);
        }
        $total = $count->count_all_results();

        $rows = $this->db->select('stock_ledger.*, products.name as product_name, products.sku as product_sku')
            ->from($this->table)
            ->join('products', 'products.id = stock_ledger.product_id', 'left');
        if (!empty($params['reference_type'])) {
            $rows->where('reference_type', $params['reference_type']);
        }
        $rows->order_by('stock_ledger.id', $params['order'])
            ->limit($params['limit'], $params['offset']);

        return array('rows' => $rows->get()->result_array(), 'total' => $total);
    }
}
