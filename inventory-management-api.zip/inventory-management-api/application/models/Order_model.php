<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order_model extends CI_Model
{
    protected $table = 'orders';
    protected $items_table = 'order_items';

    public function generate_order_no()
    {
        return 'ORD-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
    }

    protected function apply_filters($builder, $params)
    {
        if (!empty($params['search'])) {
            $builder->group_start()
                ->like('orders.order_no', $params['search'])
                ->or_like('customers.name', $params['search'])
                ->group_end();
        }
        if (!empty($params['order_status'])) {
            $builder->where('orders.order_status', $params['order_status']);
        }
        if (!empty($params['payment_status'])) {
            $builder->where('orders.payment_status', $params['payment_status']);
        }
        if (!empty($params['customer_id'])) {
            $builder->where('orders.customer_id', $params['customer_id']);
        }
        if (!empty($params['date_from'])) {
            $builder->where('orders.created_at >=', $params['date_from'] . ' 00:00:00');
        }
        if (!empty($params['date_to'])) {
            $builder->where('orders.created_at <=', $params['date_to'] . ' 23:59:59');
        }
        return $builder;
    }

    public function get_list($params)
    {
        $count = $this->db->from($this->table)
            ->join('customers', 'customers.id = orders.customer_id', 'left');
        $this->apply_filters($count, $params);
        $total = $count->count_all_results();

        $rows = $this->db->select('orders.*, customers.name as customer_name, customers.mobile as customer_mobile')
            ->from($this->table)
            ->join('customers', 'customers.id = orders.customer_id', 'left');
        $this->apply_filters($rows, $params);
        $rows->order_by('orders.' . $params['sort'], $params['order']);
        $rows->limit($params['limit'], $params['offset']);

        return array('rows' => $rows->get()->result_array(), 'total' => $total);
    }

    public function create($data)
    {
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    public function add_item($data)
    {
        return $this->db->insert($this->items_table, $data);
    }

    public function get_items($orderId)
    {
        return $this->db->select('order_items.*, products.name as product_name, products.sku as product_sku')
            ->from($this->items_table)
            ->join('products', 'products.id = order_items.product_id', 'left')
            ->where('order_items.order_id', $orderId)
            ->get()
            ->result_array();
    }

    public function find($id)
    {
        return $this->db->select('orders.*, customers.name as customer_name, customers.mobile as customer_mobile, customers.email as customer_email')
            ->from($this->table)
            ->join('customers', 'customers.id = orders.customer_id', 'left')
            ->where('orders.id', $id)
            ->get()
            ->row_array();
    }

    public function lock_for_update($id)
    {
        return $this->db->query('SELECT * FROM orders WHERE id = ? FOR UPDATE', array($id))->row_array();
    }

    public function update($id, $data)
    {
        return $this->db->where('id', $id)->update($this->table, $data);
    }

    /**
     * Recalculate payment_status based on the sum of successful transactions
     * against grand_total, and persist paid_amount + payment_status.
     */
    public function recalculate_payment_status($orderId)
    {
        $order = $this->find($orderId);
        if (!$order) {
            return FALSE;
        }

        $paid = $this->db->select_sum('amount')
            ->from('transactions')
            ->where('order_id', $orderId)
            ->where('payment_status', 'Success')
            ->get()
            ->row_array();

        $paidAmount = (float) ($paid['amount'] ?? 0);
        $grandTotal = (float) $order['grand_total'];

        $hasFailedOnly = FALSE;
        if ($paidAmount <= 0) {
            $lastTxn = $this->db->from('transactions')
                ->where('order_id', $orderId)
                ->order_by('id', 'desc')
                ->limit(1)
                ->get()
                ->row_array();
            $hasFailedOnly = $lastTxn && $lastTxn['payment_status'] === 'Failed';
        }

        if ($paidAmount <= 0) {
            $status = $hasFailedOnly ? 'Failed' : 'Pending';
        } elseif ($paidAmount < $grandTotal) {
            $status = 'Partial';
        } elseif ($paidAmount >= $grandTotal) {
            $status = 'Paid';
        }

        $refunded = $this->db->select_sum('amount')
            ->from('transactions')
            ->where('order_id', $orderId)
            ->where('payment_status', 'Refunded')
            ->get()
            ->row_array();
        if ((float) ($refunded['amount'] ?? 0) > 0 && $paidAmount <= (float) ($refunded['amount'] ?? 0)) {
            $status = 'Refunded';
        }

        $this->update($orderId, array(
            'paid_amount'    => $paidAmount,
            'payment_status' => $status,
        ));

        return $status;
    }
}
