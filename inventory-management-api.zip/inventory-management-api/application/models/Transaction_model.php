<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Transaction_model extends CI_Model
{
    protected $table = 'transactions';

    public function generate_txn_no()
    {
        return 'TXN-' . date('YmdHis') . '-' . strtoupper(substr(uniqid(), -5));
    }

    protected function apply_filters($builder, $params)
    {
        if (!empty($params['search'])) {
            $builder->group_start()
                ->like('transactions.txn_no', $params['search'])
                ->or_like('transactions.reference_no', $params['search'])
                ->group_end();
        }
        if (!empty($params['order_id'])) {
            $builder->where('transactions.order_id', $params['order_id']);
        }
        if (!empty($params['customer_id'])) {
            $builder->where('transactions.customer_id', $params['customer_id']);
        }
        if (!empty($params['payment_status'])) {
            $builder->where('transactions.payment_status', $params['payment_status']);
        }
        return $builder;
    }

    public function get_list($params)
    {
        $count = $this->db->from($this->table);
        $this->apply_filters($count, $params);
        $total = $count->count_all_results();

        $rows = $this->db->select('transactions.*, orders.order_no, customers.name as customer_name')
            ->from($this->table)
            ->join('orders', 'orders.id = transactions.order_id', 'left')
            ->join('customers', 'customers.id = transactions.customer_id', 'left');
        $this->apply_filters($rows, $params);
        $rows->order_by('transactions.' . $params['sort'], $params['order']);
        $rows->limit($params['limit'], $params['offset']);

        return array('rows' => $rows->get()->result_array(), 'total' => $total);
    }

    public function find($id)
    {
        return $this->db->select('transactions.*, orders.order_no, customers.name as customer_name')
            ->from($this->table)
            ->join('orders', 'orders.id = transactions.order_id', 'left')
            ->join('customers', 'customers.id = transactions.customer_id', 'left')
            ->where('transactions.id', $id)
            ->get()
            ->row_array();
    }

    public function create($data)
    {
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }
}
