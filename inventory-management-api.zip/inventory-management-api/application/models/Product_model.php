<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends CI_Model
{
    protected $table = 'products';

    protected function apply_filters($builder, $params)
    {
        if (!empty($params['search'])) {
            $builder->group_start()
                ->like('products.name', $params['search'])
                ->or_like('products.sku', $params['search'])
                ->group_end();
        }
        if (!empty($params['category_id'])) {
            $builder->where('products.category_id', $params['category_id']);
        }
        if (isset($params['status']) && $params['status'] !== '' && $params['status'] !== NULL) {
            $builder->where('products.status', $params['status']);
        }
        return $builder;
    }

    public function get_list($params)
    {
        $count = $this->db->from($this->table);
        $this->apply_filters($count, $params);
        $total = $count->count_all_results();

        $rows = $this->db->select('products.*, categories.name as category_name')
            ->from($this->table)
            ->join('categories', 'categories.id = products.category_id', 'left');
        $this->apply_filters($rows, $params);
        $rows->order_by('products.' . $params['sort'], $params['order']);
        $rows->limit($params['limit'], $params['offset']);

        return array('rows' => $rows->get()->result_array(), 'total' => $total);
    }

    public function find($id)
    {
        return $this->db->select('products.*, categories.name as category_name')
            ->from($this->table)
            ->join('categories', 'categories.id = products.category_id', 'left')
            ->where('products.id', $id)
            ->get()
            ->row_array();
    }

    public function sku_exists($sku, $excludeId = NULL)
    {
        $this->db->where('sku', $sku);
        if ($excludeId) {
            $this->db->where('id !=', $excludeId);
        }
        return $this->db->get($this->table)->num_rows() > 0;
    }

    public function create($data)
    {
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    public function update($id, $data)
    {
        return $this->db->where('id', $id)->update($this->table, $data);
    }

    public function delete($id)
    {
        return $this->db->where('id', $id)->delete($this->table);
    }

    /**
     * Lock the product row for update inside an active DB transaction
     * (prevents race conditions on concurrent stock deduction).
     */
    public function lock_for_update($id)
    {
        return $this->db->query('SELECT * FROM products WHERE id = ? FOR UPDATE', array($id))->row_array();
    }

    public function adjust_stock($id, $delta)
    {
        // delta can be positive (stock in) or negative (stock out)
        return $this->db->set('stock', 'stock + (' . (int) $delta . ')', FALSE)
            ->where('id', $id)
            ->update($this->table);
    }

    public function low_stock($threshold)
    {
        return $this->db->select('id, sku, name, stock, category_id')
            ->from($this->table)
            ->where('stock <=', $threshold)
            ->where('status', 1)
            ->order_by('stock', 'asc')
            ->get()
            ->result_array();
    }
}
