<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Role_model extends CI_Model
{
    protected $table = 'roles';

    public function get_list($params)
    {
        $builder = $this->db->from($this->table);

        if (!empty($params['search'])) {
            $builder->like('name', $params['search']);
        }

        $total = $builder->count_all_results('', FALSE);

        $rows = $this->db->from($this->table);
        if (!empty($params['search'])) {
            $rows->like('name', $params['search']);
        }
        $rows->order_by($params['sort'], $params['order']);
        $rows->limit($params['limit'], $params['offset']);

        return array('rows' => $rows->get()->result_array(), 'total' => $total);
    }

    public function find($id)
    {
        return $this->db->where('id', $id)->get($this->table)->row_array();
    }

    public function name_exists($name, $excludeId = NULL)
    {
        $this->db->where('name', $name);
        if ($excludeId) {
            $this->db->where('id !=', $excludeId);
        }
        return $this->db->get($this->table)->num_rows() > 0;
    }

    public function create($data)
    {
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    public function update($id, $data)
    {
        return $this->db->where('id', $id)->update($this->table, $data);
    }

    public function delete($id)
    {
        return $this->db->where('id', $id)->delete($this->table);
    }

    public function is_in_use($id)
    {
        return $this->db->where('role_id', $id)->get('users')->num_rows() > 0;
    }
}
